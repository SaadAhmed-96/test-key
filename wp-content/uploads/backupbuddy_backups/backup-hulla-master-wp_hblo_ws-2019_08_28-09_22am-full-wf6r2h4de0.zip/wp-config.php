<?php
define( 'WP_CACHE', false ); 
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */
// ** MySQL settings - You can get this info from your web host ** //
define('DB_NAME', 'qguvjteqbw');
define('DB_USER', 'qguvjteqbw');
define('DB_PASSWORD', 'SP7mtrjw52');
define('DB_HOST', 'localhost');
define('DB_CHARSET', 'utf8mb4');
define('DB_COLLATE', '');
/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         ']q;8JXgm)8OWhDe7IB5k:}i[O2iJv3fl2K`L%RY5pMp)V7*O=>$OyQYTyf5HW9;~');
define('SECURE_AUTH_KEY',  '|Zn1Pdv2{3X0L6mhrpd9 y(V?nB iR;ZV.?Lv95vS{Z)wF!Y7`>sOHfuH-MGp#9}');
define('LOGGED_IN_KEY',    'eVy+e1o{4Z&4Gc?(!dfYl+=P@a9wWh1,>^DD>x{u0(^RaLcjuMfE=WC463#SW5G ');
define('NONCE_KEY',        '?eM1AMEnoyAtq(xc0$[On (*G+vp}XIK@`_etb5qjpcz9wlrZfq7c^:76#rb{ifF');
define('AUTH_SALT',        '>+a8Ci]ad%F_g^5F4J;x<qNtxD~+J;W1Vs53FYa<!b*jYb0sD+u+m/cmN)#=JQi^');
define('SECURE_AUTH_SALT', 'wiX3@{?< {;r}d4S 0Iz/1M{l{<ZlEWNu*4R?p^`5~K>(<t_IL.I<`VeT,As{n)t');
define('LOGGED_IN_SALT',   'JthjY}1:QNns4%Z?9G~8MQ0PV<sTz*NCPX]J.S%X_s2)dzYP1;jGJY(XW5,w?6$^');
define('NONCE_SALT',       'A3gbheai8iC!,18MlM:)*>61v2h+6diEKPM6M{2NT0K0)mOVS6w~f]J|aYEn_W9m');
$table_prefix  = 'masterWPhulla_';
## Debug
define('WP_DEBUG', false);
define( 'WP_DEBUG_LOG', true );
define( 'WP_DEBUG_DISPLAY', false );
## CRON JOB
// define('DISABLE_WP_CRON', true);
## WP Settings
define( 'DISALLOW_FILE_EDIT', true );
define( 'WP_POST_REVISIONS', 5 );
define( 'WP_AUTO_UPDATE_CORE', false );
define('FS_METHOD', 'direct');
## Contact Form 7
define('WPCF7_AUTOP', false);
## SSL
define('FORCE_SSL_ADMIN', true);
## Cloudways Fix for Remote IP Address
if(isset($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $xffaddrs = explode(',',$_SERVER['HTTP_X_FORWARDED_FOR']); 
    $_SERVER['REMOTE_ADDR'] = $xffaddrs[0]; 
}
/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');
/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');